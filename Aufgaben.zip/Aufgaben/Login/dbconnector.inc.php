<?php
    $servername = "localhost";
    $username = "webuser";
    $password = "password1234";
    $db = "students";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $db);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
